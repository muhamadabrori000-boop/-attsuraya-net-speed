# ATTSURAYA NET SPEED — paket awal aplikasi online bersama

## Yang sudah disiapkan
- Dashboard HTML versi v7 ditempatkan sebagai aplikasi web.
- Login admin di sisi server, sesi cookie HttpOnly, hash kata sandi bcrypt, pembatasan percobaan login.
- Database PostgreSQL untuk menyimpan satu snapshot data aplikasi per akun admin.
- Sinkronisasi snapshot antardevice setelah login. Perubahan dikirim ke server secara berkala.
- Saat database kosong, layar awal menawarkan untuk menyalin data lokal HP ini atau mulai kosong.

## Penting — belum online/live
Paket ini adalah source code siap deploy, bukan situs yang sudah di-host. Untuk dapat dipakai dari beberapa HP, Anda atau penyedia hosting perlu membuat database PostgreSQL dan memasang paket ini di hosting Node.js dengan HTTPS. Saya tidak dapat mengaktifkan hosting tanpa akun/akses hosting Anda.

## Cara deploy yang disarankan
1. Pilih hosting yang mendukung Node.js 20+ dan PostgreSQL, dengan HTTPS.
2. Unggah/ekstrak semua isi ZIP.
3. Buat database PostgreSQL.
4. Masukkan environment variables berdasarkan `.env.example`:
   - `DATABASE_URL`: alamat database dari penyedia hosting.
   - `PGSSL=true` bila penyedia mensyaratkan SSL.
   - `SESSION_SECRET`: rahasia acak minimal 32 karakter.
   - `ADMIN_USERNAME`: nama login awal.
   - `ADMIN_PASSWORD`: kata sandi awal kuat, minimal 12 karakter.
   - `NODE_ENV=production`.
5. Jalankan `npm install`, lalu `npm start`.
6. Buka URL HTTPS dari hosting. Login admin. Pada HP pertama, pilih “Salin data HP ini ke database online” jika HP tersebut menyimpan data pelanggan yang benar. HP berikutnya login ke URL yang sama dan data akan diambil dari server.
7. Buat backup database sebelum memakai data produksi.

## Peringatan data
- Ketika database sudah berisi data, server akan memuat snapshot server ke browser. Data lokal HP kedua tidak otomatis digabung. Ekspor/backup data lama sebelum beralih.
- Snapshot sync ini adalah fondasi awal, belum mempunyai penggabungan perubahan tingkat-record atau deteksi konflik. Jika dua HP mengubah data yang sama hampir bersamaan, pembaruan terakhir dapat menimpa pembaruan sebelumnya. Untuk operasional produksi, tahap berikutnya sebaiknya mengganti snapshot dengan tabel terpisah untuk pelanggan, tagihan, pembayaran, dan transaksi serta audit log.
- Jangan bagikan kata sandi admin. Gunakan akun admin yang kuat dan backup rutin.
- Integrasi RouterOS/PPPoE **belum aktif**. Paket ini tidak mengisolir pelanggan atau mengubah router.
- Pengingat WhatsApp otomatis terjadwal, AI voice-to-entry, dan penerbitan ke Google Play **belum diaktifkan** oleh paket ini.
- Login lama yang berada di dalam HTML masih ada sebagai lapisan lokal tambahan; login online server adalah lapisan terpisah. Jangan menganggap login lokal lama sebagai keamanan server.
