const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined });
const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!process.env.DATABASE_URL || !SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('Atur DATABASE_URL dan SESSION_SECRET (minimal 32 karakter) pada environment.');
  process.exit(1);
}
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '8mb' }));
app.use(session({
  store: new PgSession({ pool, tableName: 'user_sessions', createTableIfMissing: true }),
  name: 'attsuraya.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', maxAge: 8 * 60 * 60 * 1000 }
}));
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const requireAuth = (req, res, next) => req.session && req.session.userId ? next() : res.status(401).json({ error: 'Sesi berakhir. Silakan masuk kembali.' });

async function init() {
 await pool.query(`CREATE TABLE IF NOT EXISTS app_users (
   id SERIAL PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
 )`);
 await pool.query(`CREATE TABLE IF NOT EXISTS app_state (
   user_id INTEGER PRIMARY KEY REFERENCES app_users(id) ON DELETE CASCADE,
   data JSONB NOT NULL DEFAULT '{}'::jsonb, updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
 )`);
 const username = process.env.ADMIN_USERNAME || 'admin';
 const password = process.env.ADMIN_PASSWORD;
 if (!password || password.length < 12) throw new Error('ADMIN_PASSWORD wajib diisi dan minimal 12 karakter.');
 const found = await pool.query('SELECT id FROM app_users WHERE username=$1', [username]);
 if (!found.rowCount) {
   const hash = await bcrypt.hash(password, 12);
   await pool.query('INSERT INTO app_users(username,password_hash) VALUES($1,$2)', [username, hash]);
   console.log('Admin awal dibuat. Simpan kredensial dengan aman.');
 } else {
   console.log('Akun admin sudah ada; tidak mengganti kata sandi otomatis.');
 }
}
app.get('/api/health', async (_req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true})}catch{res.status(503).json({ok:false})}});
app.post('/api/login', loginLimiter, async (req,res)=>{
 const { username, password } = req.body || {};
 if (typeof username !== 'string' || typeof password !== 'string' || username.length > 120 || password.length > 300) return res.status(400).json({error:'Nama admin atau kata sandi tidak valid.'});
 const q = await pool.query('SELECT id,username,password_hash FROM app_users WHERE username=$1',[username.trim()]);
 if (!q.rowCount || !(await bcrypt.compare(password,q.rows[0].password_hash))) return res.status(401).json({error:'Nama admin atau kata sandi salah.'});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Gagal membuat sesi.'});req.session.userId=q.rows[0].id;req.session.username=q.rows[0].username;req.session.save(e=>e?res.status(500).json({error:'Gagal menyimpan sesi.'}):res.json({ok:true,username:q.rows[0].username}));});
});
app.get('/api/me', requireAuth, (req,res)=>res.json({ok:true,username:req.session.username}));
app.post('/api/logout', requireAuth, (req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get('/api/state', requireAuth, async (req,res)=>{
 const q=await pool.query('SELECT data,updated_at FROM app_state WHERE user_id=$1',[req.session.userId]);
 if(!q.rowCount)return res.json({exists:false,data:{}});
 res.json({exists:true,data:q.rows[0].data,updatedAt:q.rows[0].updated_at});
});
app.put('/api/state', requireAuth, async (req,res)=>{
 const data=req.body && req.body.data;
 if(!data || typeof data!=='object' || Array.isArray(data))return res.status(400).json({error:'Format data tidak valid.'});
 if(Buffer.byteLength(JSON.stringify(data),'utf8')>7*1024*1024)return res.status(413).json({error:'Data terlalu besar (maksimal 7 MB).'});
 const existing=await pool.query('SELECT user_id FROM app_state WHERE user_id=$1',[req.session.userId]);
 if(!existing.rowCount && req.body.initialize!==true)return res.status(409).json({error:'Database kosong. Pilih opsi inisialisasi terlebih dahulu.'});
 await pool.query(`INSERT INTO app_state(user_id,data,updated_at) VALUES($1,$2::jsonb,now())
   ON CONFLICT(user_id) DO UPDATE SET data=EXCLUDED.data,updated_at=now()`,
   [req.session.userId,JSON.stringify(data)]);
 res.json({ok:true,updatedAt:new Date().toISOString()});
});
app.use(express.static(path.join(__dirname,'public'), { extensions:['html'] }));
app.use((_req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
init().then(()=>app.listen(PORT,()=>console.log(`ATTSURAYA online server listening on ${PORT}`))).catch(e=>{console.error(e);process.exit(1)});
